package com.example.wifiinspect

import android.app.Application
import com.example.wifiinspect.wifi.OuiLookup

class WifiInspectApp : Application() {
    val ouiLookup: OuiLookup by lazy { OuiLookup(this) }

    override fun onCreate() {
        super.onCreate()
        INSTANCE = this
    }

    companion object {
        lateinit var INSTANCE: WifiInspectApp
            private set
    }
}
