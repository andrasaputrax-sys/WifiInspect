package com.example.wifiinspect.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wifiinspect.WifiInspectApp
import com.example.wifiinspect.data.Prefs
import com.example.wifiinspect.work.AutoScanWorker
import com.example.wifiinspect.data.ScanHistoryRepository
import com.example.wifiinspect.databinding.ActivityMainBinding
import com.example.wifiinspect.permissions.PermissionFlow
import com.example.wifiinspect.wifi.NetworkEntry
import com.example.wifiinspect.wifi.ScanOutcome
import com.example.wifiinspect.wifi.WifiAnalyzer
import com.example.wifiinspect.wifi.WifiScanner
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var scanner: WifiScanner
    private lateinit var adapter: NetworkAdapter
    private lateinit var permissionFlow: PermissionFlow
    private var lastEntries: List<NetworkEntry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val app = application as WifiInspectApp
        scanner = WifiScanner(this, app.ouiLookup)

        permissionFlow = PermissionFlow(this) { granted ->
            if (granted) runScan() else binding.txtScanStatus.text = "Tanpa izin lokasi, SSID/BSSID tidak bisa ditampilkan (batasan sistem Android)."
        }
        permissionFlow.register(this)

        adapter = NetworkAdapter { entry ->
            startActivity(NetworkDetailActivity.intentFor(this, entry))
        }
        binding.listNetworks.layoutManager = LinearLayoutManager(this)
        binding.listNetworks.adapter = adapter

        binding.switchAutoScan.isChecked = Prefs.autoScanEnabled(this)
        binding.switchAutoScan.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoScanEnabled(this, checked)
            if (checked) {
                if (permissionFlow.hasPermission()) AutoScanWorker.enable(this)
                else { binding.switchAutoScan.isChecked = false; permissionFlow.request() }
            } else {
                AutoScanWorker.disable(this)
            }
        }

        binding.btnScan.setOnClickListener { requestOrScan() }
        binding.btnDiagnostics.setOnClickListener { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        binding.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }

        refreshConnectionCard()
    }

    override fun onResume() {
        super.onResume()
        refreshConnectionCard()
    }

    private fun requestOrScan() {
        if (permissionFlow.hasPermission()) runScan() else permissionFlow.request()
    }

    private fun refreshConnectionCard() {
        if (!scanner.hasLocationPermission()) {
            binding.txtConnStatus.text = "Izin lokasi belum diberikan"
            binding.txtConnDetail.text = "Diperlukan agar Android mengizinkan nama jaringan ditampilkan."
            return
        }
        val info = scanner.currentConnectionInfo()
        if (info == null || !info.isWifi) {
            binding.txtConnStatus.text = "Tidak tersambung ke WiFi"
            binding.txtConnDetail.text = ""
            return
        }
        binding.txtConnStatus.text = "Tersambung: ${info.ssid ?: "(tidak diketahui)"}"
        val vendor = info.vendor?.let { " • $it" } ?: ""
        val freq = info.frequencyMhz?.let { " • " + com.example.wifiinspect.wifi.ChannelUtil.label(it) } ?: ""
        binding.txtConnDetail.text = "${info.bssid ?: "?"}$vendor$freq\nSinyal: ${info.rssi ?: "?"} dBm • Kecepatan tautan: ${info.linkSpeedMbps ?: "?"} Mbps" +
            if (!info.isValidated) "\n⚠ Tidak ada akses internet terverifikasi di jaringan ini." else ""
    }

    private fun runScan() {
        binding.txtScanStatus.text = "Memindai..."
        scanner.scan { outcome ->
            runOnUiThread {
                when (outcome) {
                    is ScanOutcome.Failure -> binding.txtScanStatus.text = outcome.reason
                    is ScanOutcome.Success -> {
                        lastEntries = outcome.entries
                        adapter.submit(outcome.entries)
                        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                        val warnings = WifiAnalyzer.duplicateSsidWarning(outcome.entries)
                        binding.txtScanStatus.text = "Ditemukan ${outcome.entries.size} jaringan • $time" +
                            if (warnings.isNotEmpty()) "\n⚠ " + warnings.first() else ""
                        lifecycleScope.launch { ScanHistoryRepository.save(this@MainActivity, outcome.entries) }
                        refreshConnectionCard()
                    }
                }
            }
        }
    }
}
