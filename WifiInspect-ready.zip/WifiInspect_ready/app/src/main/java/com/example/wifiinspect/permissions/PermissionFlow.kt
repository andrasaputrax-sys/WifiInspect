package com.example.wifiinspect.permissions

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.example.wifiinspect.R

/** Alur minta ACCESS_FINE_LOCATION dengan penjelasan dulu (bukan langsung muncul dialog sistem tanpa konteks). */
class PermissionFlow(private val activity: Activity, private val onResult: (Boolean) -> Unit) {

    private var launcher: ActivityResultLauncher<String>? = null

    fun register(caller: androidx.activity.result.ActivityResultCaller) {
        launcher = caller.registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            onResult(granted)
        }
    }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun request() {
        if (hasPermission()) { onResult(true); return }
        AlertDialog.Builder(activity)
            .setTitle(R.string.need_location_title)
            .setMessage(R.string.need_location_body)
            .setPositiveButton(R.string.grant) { _, _ -> launcher?.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
