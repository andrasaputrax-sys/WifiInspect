package com.example.wifiinspect.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wifiinspect.data.ScanHistoryRepository
import com.example.wifiinspect.databinding.ActivityHistoryBinding
import kotlinx.coroutines.launch

/** Menampilkan ulang isi satu hasil pemindaian dari riwayat (read-only, tidak memindai ulang). */
class NetworkListPreviewActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.listHistory.layoutManager = LinearLayoutManager(this)
        val adapter = NetworkAdapter { entry -> startActivity(NetworkDetailActivity.intentFor(this, entry)) }
        binding.listHistory.adapter = adapter

        val batchId = intent.getLongExtra(EXTRA_BATCH_ID, -1)
        lifecycleScope.launch {
            val entries = ScanHistoryRepository.entriesOf(this@NetworkListPreviewActivity, batchId)
            binding.txtEmpty.visibility = if (entries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            adapter.submit(entries)
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    companion object {
        private const val EXTRA_BATCH_ID = "batch_id"
        fun intentFor(ctx: Context, batchId: Long): Intent =
            Intent(ctx, NetworkListPreviewActivity::class.java).putExtra(EXTRA_BATCH_ID, batchId)
    }
}
