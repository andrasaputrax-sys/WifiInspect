package com.example.wifiinspect.work

import android.content.Context
import androidx.work.*
import com.example.wifiinspect.WifiInspectApp
import com.example.wifiinspect.data.ScanHistoryRepository
import com.example.wifiinspect.wifi.ScanOutcome
import com.example.wifiinspect.wifi.WifiScanner
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * Pemindaian berkala opsional (MATI secara default; pengguna aktifkan sendiri dari Pengaturan).
 * Interval wajar (15 menit) sesuai batas minimum WorkManager, menghormati pembatasan baterai/
 * background Android modern alih-alih service yang jalan terus-menerus.
 */
class AutoScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as WifiInspectApp
        val scanner = WifiScanner(applicationContext, app.ouiLookup)
        if (!scanner.hasLocationPermission() || !scanner.isWifiEnabled()) return Result.success()

        val outcome = suspendCancellableCoroutine<ScanOutcome> { cont ->
            scanner.scan { cont.resume(it) }
        }
        if (outcome is ScanOutcome.Success) {
            ScanHistoryRepository.save(applicationContext, outcome.entries)
        }
        return Result.success()
    }

    companion object {
        private const val NAME = "auto_scan_periodic"

        fun enable(context: Context) {
            val req = PeriodicWorkRequestBuilder<AutoScanWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun disable(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(NAME)
        }

        fun isEnabled(context: Context, callback: (Boolean) -> Unit) {
            val future = WorkManager.getInstance(context).getWorkInfosForUniqueWork(NAME)
            future.addListener({
                val infos = try { future.get() } catch (e: Exception) { emptyList() }
                callback(infos.any { !it.state.isFinished })
            }, androidx.core.content.ContextCompat.getMainExecutor(context))
        }
    }
}
