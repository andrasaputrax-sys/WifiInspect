package com.example.wifiinspect.wifi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

sealed class ScanOutcome {
    data class Success(val entries: List<NetworkEntry>) : ScanOutcome()
    data class Failure(val reason: String) : ScanOutcome()
}

/**
 * Pembungkus WifiManager untuk memindai jaringan sekitar dan membaca info koneksi aktif.
 * Tidak pernah mencoba connect/disconnect ke jaringan apa pun — hanya membaca.
 */
class WifiScanner(private val context: Context, private val oui: OuiLookup) {

    private val wifiManager: WifiManager by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    }
    private val connectivityManager: ConnectivityManager by lazy {
        context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    }

    fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun isWifiEnabled(): Boolean = wifiManager.isWifiEnabled

    /**
     * Memulai satu pemindaian dan memanggil [callback] saat hasil siap.
     * Android membatasi throttle: app foreground umumnya dibatasi ~4x per 2 menit (lebih ketat di
     * background); jika throttle aktif, [WifiManager.startScan] tetap akan mengembalikan hasil
     * pemindaian TERAKHIR yang tersedia, bukan error — jadi kita tetap tampilkan apa adanya dan
     * beri tahu pengguna lewat timestamp hasil.
     */
    fun scan(callback: (ScanOutcome) -> Unit) {
        if (!hasLocationPermission()) {
            callback(ScanOutcome.Failure("Izin lokasi presisi belum diberikan; SSID/BSSID tidak bisa dibaca."))
            return
        }
        if (!isWifiEnabled()) {
            callback(ScanOutcome.Failure("WiFi sedang mati. Aktifkan WiFi lalu coba lagi."))
            return
        }

        val handled = AtomicBoolean(false)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (!handled.compareAndSet(false, true)) return
                try { context.unregisterReceiver(this) } catch (_: Exception) {}
                val success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, true)
                deliverResults(success, callback)
            }
        }
        context.registerReceiver(receiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))

        val started = try { wifiManager.startScan() } catch (e: Exception) { false }
        if (!started) {
            // Throttle atau kegagalan lain: tetap tampilkan hasil scan terakhir yang disimpan sistem.
            if (handled.compareAndSet(false, true)) {
                try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
                deliverResults(false, callback)
            }
        }
    }

    private fun deliverResults(fresh: Boolean, callback: (ScanOutcome) -> Unit) {
        try {
            val results = wifiManager.scanResults
            val connectedBssid = currentConnectionInfo()?.bssid
            val entries = results.map { r ->
                NetworkEntry(
                    ssid = r.SSID ?: "",
                    bssid = r.BSSID ?: "",
                    capabilities = r.capabilities ?: "",
                    frequencyMhz = r.frequency,
                    levelDbm = r.level,
                    timestampMillis = System.currentTimeMillis(),
                    vendor = oui.vendorOf(r.BSSID),
                    isConnected = connectedBssid != null && connectedBssid.equals(r.BSSID, ignoreCase = true)
                )
            }.sortedByDescending { it.levelDbm }
            callback(
                ScanOutcome.Success(entries).let {
                    if (!fresh && entries.isEmpty()) ScanOutcome.Failure("Belum ada hasil pemindaian tersimpan dan pemindaian baru dibatasi sistem (throttle). Coba lagi sebentar lagi.")
                    else it
                }
            )
        } catch (e: SecurityException) {
            callback(ScanOutcome.Failure("Izin ditolak saat membaca hasil pemindaian."))
        }
    }

    data class ConnectionInfo(
        val ssid: String?,
        val bssid: String?,
        val rssi: Int?,
        val linkSpeedMbps: Int?,
        val frequencyMhz: Int?,
        val vendor: String?,
        val isWifi: Boolean,
        val isValidated: Boolean
    )

    /** Info jaringan WiFi yang sedang aktif, lewat ConnectivityManager + NetworkCapabilities (cara modern, bukan API usang). */
    fun currentConnectionInfo(): ConnectionInfo? {
        val network: Network = connectivityManager.activeNetwork ?: return null
        val caps: NetworkCapabilities = connectivityManager.getNetworkCapabilities(network) ?: return null
        val isWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        if (!isWifi) return ConnectionInfo(null, null, null, null, null, null, false, caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))

        val info = if (Build.VERSION.SDK_INT >= 29) {
            val transportInfo = caps.transportInfo
            if (transportInfo is android.net.wifi.WifiInfo) transportInfo else null
        } else {
            @Suppress("DEPRECATION")
            wifiManager.connectionInfo
        }
        if (info == null) return ConnectionInfo(null, null, null, null, null, null, true, caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))

        val rawSsid = info.ssid?.removePrefix("\"")?.removeSuffix("\"")
        val ssid = if (rawSsid == WifiManager.UNKNOWN_SSID) null else rawSsid
        val bssid = if (info.bssid == "02:00:00:00:00:00") null else info.bssid
        return ConnectionInfo(
            ssid = ssid,
            bssid = bssid,
            rssi = info.rssi,
            linkSpeedMbps = info.linkSpeed,
            frequencyMhz = if (Build.VERSION.SDK_INT >= 21) info.frequency else null,
            vendor = oui.vendorOf(bssid),
            isWifi = true,
            isValidated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        )
    }
}
