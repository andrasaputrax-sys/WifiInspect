package com.example.wifiinspect.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.wifiinspect.R
import com.example.wifiinspect.databinding.ActivityNetworkDetailBinding
import com.example.wifiinspect.wifi.ChannelUtil
import com.example.wifiinspect.wifi.NetworkEntry
import com.example.wifiinspect.wifi.Risk
import com.example.wifiinspect.wifi.WifiAnalyzer

class NetworkDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNetworkDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNetworkDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val ssid = intent.getStringExtra(EXTRA_SSID) ?: ""
        val bssid = intent.getStringExtra(EXTRA_BSSID) ?: ""
        val caps = intent.getStringExtra(EXTRA_CAPS) ?: ""
        val freq = intent.getIntExtra(EXTRA_FREQ, 0)
        val level = intent.getIntExtra(EXTRA_LEVEL, 0)
        val vendor = intent.getStringExtra(EXTRA_VENDOR)

        binding.txtSsid.text = ssid.ifBlank { "(SSID tersembunyi)" }
        binding.txtBssid.text = bssid

        val rows = StringBuilder()
        rows.append("Vendor: ").append(vendor ?: "tidak diketahui").append('\n')
        rows.append("Frekuensi: ").append(ChannelUtil.label(freq)).append('\n')
        rows.append("Kekuatan sinyal: ").append(level).append(" dBm\n")
        rows.append("Kapabilitas mentah: ").append(caps)
        binding.txtRows.text = rows.toString()

        val a = WifiAnalyzer.assess(caps)
        binding.txtSecTitle.text = "Keamanan: ${a.level}" + if (a.wpsEnabled) " • WPS aktif" else ""
        binding.txtSecExplain.text = a.explanation
        val color = when (a.risk) { Risk.GOOD -> R.color.sec_good; Risk.WARN -> R.color.sec_warn; Risk.BAD -> R.color.sec_bad }
        binding.txtSecTitle.setTextColor(getColor(color))
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    companion object {
        private const val EXTRA_SSID = "ssid"
        private const val EXTRA_BSSID = "bssid"
        private const val EXTRA_CAPS = "caps"
        private const val EXTRA_FREQ = "freq"
        private const val EXTRA_LEVEL = "level"
        private const val EXTRA_VENDOR = "vendor"

        fun intentFor(ctx: Context, e: NetworkEntry): Intent =
            Intent(ctx, NetworkDetailActivity::class.java)
                .putExtra(EXTRA_SSID, e.ssid)
                .putExtra(EXTRA_BSSID, e.bssid)
                .putExtra(EXTRA_CAPS, e.capabilities)
                .putExtra(EXTRA_FREQ, e.frequencyMhz)
                .putExtra(EXTRA_LEVEL, e.levelDbm)
                .putExtra(EXTRA_VENDOR, e.vendor)
    }
}
