package com.example.wifiinspect.wifi

enum class SecurityLevel { OPEN, WEP, WPA2, WPA3, UNKNOWN }

enum class Risk { GOOD, WARN, BAD }

data class SecurityAssessment(
    val level: SecurityLevel,
    val risk: Risk,
    val wpsEnabled: Boolean,
    /** Penjelasan dalam bahasa sederhana, bukan istilah teknis mentah. */
    val explanation: String
)

/** Satu hasil pemindaian, sudah diterjemahkan dari android.net.wifi.ScanResult (tidak menyimpan objek Android agar mudah diuji & disimpan ke Room). */
data class NetworkEntry(
    val ssid: String,
    val bssid: String,
    val capabilities: String,
    val frequencyMhz: Int,
    val levelDbm: Int,
    val timestampMillis: Long,
    val vendor: String?,
    val isConnected: Boolean = false
) {
    val band: ChannelUtil.Band get() = ChannelUtil.band(frequencyMhz)
    val channel: Int get() = ChannelUtil.channel(frequencyMhz)

    /** 0..100, dari RSSI dBm. Rumus umum dipakai Android sendiri (WifiManager.calculateSignalLevel). */
    fun signalPercent(): Int {
        val minDbm = -100
        val maxDbm = -55
        val clamped = levelDbm.coerceIn(minDbm, maxDbm)
        return ((clamped - minDbm).toFloat() / (maxDbm - minDbm) * 100).toInt()
    }

    val displaySsid: String get() = if (ssid.isBlank()) "(SSID tersembunyi)" else ssid
}
