package com.example.wifiinspect.wifi

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Pencocokan 3 oktet pertama BSSID (OUI) ke nama vendor, dari data publik registry IEEE
 * (assets/oui_db.csv, format "AABBCC,Nama Vendor"). Dimuat sekali, disimpan di memori (~650KB teks).
 */
class OuiLookup(context: Context) {
    private val map: HashMap<String, String> = HashMap(24000)

    init {
        try {
            context.assets.open("oui_db.csv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).use { br ->
                    var line: String?
                    while (true) {
                        line = br.readLine() ?: break
                        val cur = line ?: break
                        val i = cur.indexOf(',')
                        if (i != 6) continue
                        map[cur.substring(0, 6)] = cur.substring(7)
                    }
                }
            }
        } catch (e: Exception) {
            // Tanpa database vendor pun aplikasi tetap berjalan; hanya nama vendor yang kosong.
        }
    }

    /** [bssid] format "AA:BB:CC:DD:EE:FF" atau tanpa pemisah. Null bila tak dikenali / MAC acak (locally administered). */
    fun vendorOf(bssid: String?): String? {
        if (bssid.isNullOrBlank()) return null
        val hex = bssid.replace(":", "").replace("-", "").uppercase()
        if (hex.length < 6) return null
        val oui = hex.substring(0, 6)
        val firstByte = oui.substring(0, 2).toIntOrNull(16) ?: return map[oui]
        // Bit kedua byte pertama = 1 berarti "locally administered" (MAC acak/randomisasi privasi),
        // bukan alamat pabrik asli -> pencarian vendor tidak berarti.
        if (firstByte and 0x02 != 0) return null
        return map[oui]
    }

    val size: Int get() = map.size
}
