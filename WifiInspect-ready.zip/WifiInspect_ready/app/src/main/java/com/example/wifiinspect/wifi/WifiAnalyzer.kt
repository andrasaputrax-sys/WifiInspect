package com.example.wifiinspect.wifi

/**
 * Menilai keamanan satu jaringan HANYA dari field `capabilities` yang disediakan Android sendiri
 * saat scan (ScanResult.capabilities). Tidak mencoba sandi/PIN apa pun, tidak menguji router
 * secara aktif — murni membaca & menerjemahkan apa yang sistem sudah laporkan.
 */
object WifiAnalyzer {

    fun assess(caps: String): SecurityAssessment {
        val c = caps.uppercase()
        val wps = c.contains("WPS")
        val level = when {
            c.contains("WPA3") || c.contains("SAE") -> SecurityLevel.WPA3
            c.contains("WPA2") || c.contains("RSN") -> SecurityLevel.WPA2
            c.contains("WPA") -> SecurityLevel.WPA2 // WPA1 lama, diperlakukan setara "perlu waspada"
            c.contains("WEP") -> SecurityLevel.WEP
            c.isBlank() || c == "[ESS]" || !c.contains("[") -> SecurityLevel.OPEN
            else -> SecurityLevel.UNKNOWN
        }
        val (risk, text) = when (level) {
            SecurityLevel.OPEN -> Risk.BAD to
                "Jaringan ini TERBUKA (tanpa sandi). Siapa pun di sekitar bisa menyadap data yang lewat jika situs/app yang Anda pakai tidak terenkripsi sendiri (bukan HTTPS)."
            SecurityLevel.WEP -> Risk.BAD to
                "Jaringan memakai WEP, standar keamanan lama yang sudah terbukti mudah dibobol sejak lebih dari 15 tahun lalu. Sebaiknya hindari, atau minta pemilik router menggantinya ke WPA2/WPA3."
            SecurityLevel.WPA2 -> Risk.WARN to
                "Jaringan memakai WPA2, cukup aman untuk kebanyakan kebutuhan sehari-hari, tapi WPA3 lebih baik bila router dan perangkat Anda mendukungnya."
            SecurityLevel.WPA3 -> Risk.GOOD to
                "Jaringan memakai WPA3, standar keamanan WiFi terkini. Tidak ada tindakan tambahan yang diperlukan."
            SecurityLevel.UNKNOWN -> Risk.WARN to
                "Jenis keamanan tidak dapat dipastikan dari data yang tersedia."
        }
        val wpsNote = if (wps)
            " Fitur WPS terdeteksi aktif di jaringan ini — WPS punya riwayat celah keamanan (PIN statis mudah ditebak pada firmware lama). Jika ini router Anda sendiri, pertimbangkan menonaktifkan WPS dari pengaturan router."
        else ""
        return SecurityAssessment(level, risk, wps, text + wpsNote)
    }

    /** Deteksi dasar "SSID kembar" (nama sama, BSSID vendor berbeda jauh / lebih dari wajar) — murni info, bukan aksi apa pun. */
    fun duplicateSsidWarning(all: List<NetworkEntry>): List<String> {
        val bySsid = all.filter { it.ssid.isNotBlank() }.groupBy { it.ssid }
        val warnings = ArrayList<String>()
        for ((ssid, entries) in bySsid) {
            val vendors = entries.mapNotNull { it.vendor }.toSet()
            if (entries.size > 1 && vendors.size > 1) {
                warnings.add("SSID \"$ssid\" muncul dari ${entries.size} access point dengan vendor berbeda ($vendors). Ini bisa wajar (roaming WiFi mesh/enterprise), tapi juga bisa pertanda jaringan tiruan (\"evil twin\"). Periksa dengan pemilik jaringan jika ragu.")
            }
        }
        return warnings
    }
}
