package com.example.wifiinspect.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.wifiinspect.R
import com.example.wifiinspect.databinding.ItemNetworkBinding
import com.example.wifiinspect.wifi.NetworkEntry
import com.example.wifiinspect.wifi.Risk
import com.example.wifiinspect.wifi.WifiAnalyzer

class NetworkAdapter(
    private var items: List<NetworkEntry> = emptyList(),
    private val onClick: (NetworkEntry) -> Unit
) : RecyclerView.Adapter<NetworkAdapter.VH>() {

    inner class VH(val b: ItemNetworkBinding) : RecyclerView.ViewHolder(b.root)

    fun submit(newItems: List<NetworkEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemNetworkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        val ctx = holder.b.root.context
        holder.b.txtSsid.text = (if (e.isConnected) "✓ " else "") + e.displaySsid
        val vendor = e.vendor?.let { " • $it" } ?: ""
        holder.b.txtMeta.text = "${e.bssid}$vendor\n" + com.example.wifiinspect.wifi.ChannelUtil.label(e.frequencyMhz)
        holder.b.txtSignal.text = "${e.levelDbm} dBm\n${e.signalPercent()}%"
        val assessment = WifiAnalyzer.assess(e.capabilities)
        val color = when (assessment.risk) {
            Risk.GOOD -> R.color.sec_good
            Risk.WARN -> R.color.sec_warn
            Risk.BAD -> R.color.sec_bad
        }
        holder.b.riskDot.setBackgroundColor(ctx.getColor(color))
        holder.b.root.setOnClickListener { onClick(e) }
    }
}
