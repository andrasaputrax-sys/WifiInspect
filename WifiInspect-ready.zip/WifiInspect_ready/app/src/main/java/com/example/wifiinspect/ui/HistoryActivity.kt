package com.example.wifiinspect.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.wifiinspect.data.ScanBatchRow
import com.example.wifiinspect.data.ScanHistoryRepository
import com.example.wifiinspect.databinding.ActivityHistoryBinding
import com.example.wifiinspect.databinding.ItemHistoryBinding
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.listHistory.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val batches = ScanHistoryRepository.history(this@HistoryActivity)
            binding.txtEmpty.visibility = if (batches.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            binding.listHistory.adapter = HistoryAdapter(batches) { batch ->
                startActivity(NetworkListPreviewActivity.intentFor(this@HistoryActivity, batch.id))
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class HistoryAdapter(private val items: List<ScanBatchRow>, private val onClick: (ScanBatchRow) -> Unit) :
    RecyclerView.Adapter<HistoryAdapter.VH>() {
    inner class VH(val b: ItemHistoryBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): VH {
        val b = ItemHistoryBinding.inflate(android.view.LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val b = items[position]
        val fmt = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
        holder.b.txtTime.text = fmt.format(Date(b.timestampMillis))
        holder.b.txtCount.text = "${b.networkCount} jaringan ditemukan"
        holder.b.root.setOnClickListener { onClick(b) }
    }
}
