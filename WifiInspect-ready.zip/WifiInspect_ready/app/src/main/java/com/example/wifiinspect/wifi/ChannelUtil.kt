package com.example.wifiinspect.wifi

/** Konversi frekuensi WiFi (MHz) ke band & nomor channel. Rumus standar IEEE 802.11, bukan hasil tebakan. */
object ChannelUtil {

    enum class Band(val label: String) { GHZ_24("2.4 GHz"), GHZ_5("5 GHz"), GHZ_6("6 GHz"), UNKNOWN("?") }

    fun band(freqMhz: Int): Band = when (freqMhz) {
        in 2401..2495 -> Band.GHZ_24
        in 5150..5895 -> Band.GHZ_5
        in 5925..7125 -> Band.GHZ_6
        else -> Band.UNKNOWN
    }

    /** Mengembalikan nomor channel, atau -1 bila frekuensi tidak dikenali. */
    fun channel(freqMhz: Int): Int {
        return when {
            freqMhz == 2484 -> 14
            freqMhz in 2412..2472 -> (freqMhz - 2407) / 5
            freqMhz in 5160..5885 -> (freqMhz - 5000) / 5
            freqMhz in 5955..7115 -> (freqMhz - 5950) / 5
            else -> -1
        }
    }

    fun label(freqMhz: Int): String {
        val b = band(freqMhz)
        val ch = channel(freqMhz)
        return if (ch < 0) "${freqMhz} MHz" else "${b.label} • ch $ch (${freqMhz} MHz)"
    }
}
