package com.example.wifiinspect.diagnostics

import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs
import kotlin.math.sqrt

data class PingSample(val ok: Boolean, val millis: Long)

data class PingSummary(
    val target: String,
    val sent: Int,
    val received: Int,
    val avgMs: Double,
    val jitterMs: Double,
    val lossPercent: Double,
    val method: String
)

/**
 * Pengukuran latency tanpa root dan tanpa raw ICMP socket (butuh izin khusus di sejumlah
 * perangkat/ROM). Dua metode, dipilih otomatis:
 *  1) InetAddress.isReachable() — pada banyak perangkat ini mencoba ICMP echo lebih dulu.
 *  2) Fallback: waktu membuka koneksi TCP ke port 443/80 — bukan ping murni, tapi representatif
 *     untuk "apakah jalur ke host ini responsif", dan diberi label jelas di UI.
 */
object PingTool {

    fun pingHost(host: String, port: Int = 443, count: Int = 6, timeoutMs: Int = 1500): PingSummary {
        val samples = ArrayList<PingSample>(count)
        var usedTcpFallback = false
        for (i in 0 until count) {
            val start = System.nanoTime()
            var ok = false
            try {
                val addr = java.net.InetAddress.getByName(host)
                ok = addr.isReachable(timeoutMs)
                if (!ok) throw java.io.IOException("ICMP tidak terjangkau/diblokir")
            } catch (e: Exception) {
                usedTcpFallback = true
                ok = try {
                    Socket().use { s ->
                        s.connect(InetSocketAddress(host, port), timeoutMs)
                        true
                    }
                } catch (e2: Exception) { false }
            }
            val elapsedMs = (System.nanoTime() - start) / 1_000_000
            samples.add(PingSample(ok, elapsedMs))
        }
        val ok = samples.filter { it.ok }
        val avg = if (ok.isNotEmpty()) ok.map { it.millis }.average() else -1.0
        val jitter = if (ok.size >= 2) {
            val diffs = ok.zipWithNext { a, b -> abs((b.millis - a.millis).toDouble()) }
            diffs.average()
        } else 0.0
        val loss = (count - ok.size).toDouble() / count * 100.0
        return PingSummary(
            target = host,
            sent = count,
            received = ok.size,
            avgMs = avg,
            jitterMs = jitter,
            lossPercent = loss,
            method = if (usedTcpFallback) "TCP:$port (fallback, ICMP diblokir/tidak diizinkan)" else "ICMP (isReachable)"
        )
    }
}
