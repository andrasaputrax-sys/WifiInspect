package com.example.wifiinspect.data

import android.content.Context
import androidx.room.*
import com.example.wifiinspect.wifi.NetworkEntry

@Entity(tableName = "scan_entry")
data class ScanEntryRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val batchId: Long,
    val ssid: String,
    val bssid: String,
    val capabilities: String,
    val frequencyMhz: Int,
    val levelDbm: Int,
    val timestampMillis: Long,
    val vendor: String?
)

@Entity(tableName = "scan_batch")
data class ScanBatchRow(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampMillis: Long,
    val networkCount: Int
)

@Dao
interface ScanHistoryDao {
    @Insert
    suspend fun insertBatch(batch: ScanBatchRow): Long

    @Insert
    suspend fun insertEntries(entries: List<ScanEntryRow>)

    @Query("SELECT * FROM scan_batch ORDER BY timestampMillis DESC LIMIT 100")
    suspend fun recentBatches(): List<ScanBatchRow>

    @Query("SELECT * FROM scan_entry WHERE batchId = :batchId ORDER BY levelDbm DESC")
    suspend fun entriesFor(batchId: Long): List<ScanEntryRow>

    @Query("DELETE FROM scan_batch WHERE id NOT IN (SELECT id FROM scan_batch ORDER BY timestampMillis DESC LIMIT 100)")
    suspend fun trimOldBatches()

    @Query("DELETE FROM scan_entry WHERE batchId NOT IN (SELECT id FROM scan_batch)")
    suspend fun trimOrphanEntries()
}

@Database(entities = [ScanBatchRow::class, ScanEntryRow::class], version = 1, exportSchema = false)
abstract class ScanHistoryDatabase : RoomDatabase() {
    abstract fun dao(): ScanHistoryDao

    companion object {
        @Volatile private var INSTANCE: ScanHistoryDatabase? = null
        fun get(context: Context): ScanHistoryDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, ScanHistoryDatabase::class.java, "wifiinspect.db")
                    .build().also { INSTANCE = it }
            }
    }
}

/** Jembatan antara model domain (NetworkEntry) dan baris Room. */
object ScanHistoryRepository {
    suspend fun save(context: Context, entries: List<NetworkEntry>) {
        val dao = ScanHistoryDatabase.get(context).dao()
        val batchId = dao.insertBatch(ScanBatchRow(timestampMillis = System.currentTimeMillis(), networkCount = entries.size))
        dao.insertEntries(entries.map {
            ScanEntryRow(
                batchId = batchId, ssid = it.ssid, bssid = it.bssid, capabilities = it.capabilities,
                frequencyMhz = it.frequencyMhz, levelDbm = it.levelDbm, timestampMillis = it.timestampMillis, vendor = it.vendor
            )
        })
        dao.trimOldBatches()
        dao.trimOrphanEntries()
    }

    suspend fun history(context: Context): List<ScanBatchRow> = ScanHistoryDatabase.get(context).dao().recentBatches()

    suspend fun entriesOf(context: Context, batchId: Long): List<NetworkEntry> =
        ScanHistoryDatabase.get(context).dao().entriesFor(batchId).map {
            NetworkEntry(it.ssid, it.bssid, it.capabilities, it.frequencyMhz, it.levelDbm, it.timestampMillis, it.vendor)
        }
}
