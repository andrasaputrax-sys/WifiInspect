package com.example.wifiinspect.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.wifiinspect.WifiInspectApp
import com.example.wifiinspect.databinding.ActivityDiagnosticsBinding
import com.example.wifiinspect.diagnostics.PingSummary
import com.example.wifiinspect.diagnostics.PingTool
import com.example.wifiinspect.wifi.WifiScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.NetworkInterface

class DiagnosticsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDiagnosticsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDiagnosticsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.btnRun.setOnClickListener { run() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    private fun gatewayAddress(): String? {
        val app = application as WifiInspectApp
        val scanner = WifiScanner(this, app.ouiLookup)
        // DhcpInfo cukup untuk mendapatkan alamat gateway tanpa izin tambahan.
        return try {
            val wm = getSystemService(WIFI_SERVICE) as android.net.wifi.WifiManager
            @Suppress("DEPRECATION")
            val dhcp = wm.dhcpInfo
            val g = dhcp?.gateway ?: return null
            if (g == 0) null else
                String.format("%d.%d.%d.%d", g and 0xff, g shr 8 and 0xff, g shr 16 and 0xff, g shr 24 and 0xff)
        } catch (e: Exception) { null }
    }

    private fun run() {
        binding.btnRun.isEnabled = false
        binding.progress.visibility = android.view.View.VISIBLE
        binding.txtResult.text = ""
        val gateway = gatewayAddress()
        lifecycleScope.launch {
            val sb = StringBuilder()
            if (gateway != null) {
                val r = withContext(Dispatchers.IO) { PingTool.pingHost(gateway, port = 80) }
                sb.append(format("Router (gateway) $gateway", r))
            } else {
                sb.append("Alamat gateway tidak terdeteksi (mungkin tidak sedang tersambung WiFi).\n\n")
            }
            val dns = withContext(Dispatchers.IO) { PingTool.pingHost("8.8.8.8", port = 443) }
            sb.append(format("Internet (DNS publik 8.8.8.8)", dns))
            binding.txtResult.text = sb.toString()
            binding.progress.visibility = android.view.View.GONE
            binding.btnRun.isEnabled = true
        }
    }

    private fun format(label: String, r: PingSummary): String {
        val avg = if (r.received > 0) "%.0f ms".format(r.avgMs) else "tidak terjangkau"
        val jitter = if (r.received > 1) "%.0f ms".format(r.jitterMs) else "-"
        val stability = when {
            r.lossPercent == 0.0 && r.jitterMs < 20 -> "Stabil"
            r.lossPercent <= 20.0 -> "Cukup stabil, sesekali lambat"
            else -> "Tidak stabil"
        }
        return "$label\n" +
            "  Metode: ${r.method}\n" +
            "  Rata-rata latency: $avg\n" +
            "  Variasi (jitter): $jitter\n" +
            "  Paket hilang: %.0f%% (${r.received}/${r.sent} berhasil)\n".format(r.lossPercent) +
            "  Kesimpulan: $stability\n\n"
    }
}
