package com.example.wifiinspect.data

import android.content.Context

object Prefs {
    private const val P = "wifiinspect"
    private fun sp(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)

    fun autoScanEnabled(c: Context): Boolean = sp(c).getBoolean("auto_scan", false)
    fun setAutoScanEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_scan", v).apply()
}
