package com.example.wifiinspect.wifi

import org.junit.Assert.assertEquals
import org.junit.Test

class WifiAnalyzerTest {
    @Test fun detectsOpen() {
        assertEquals(SecurityLevel.OPEN, WifiAnalyzer.assess("[ESS]").level)
        assertEquals(Risk.BAD, WifiAnalyzer.assess("[ESS]").risk)
    }

    @Test fun detectsWpa2() {
        val a = WifiAnalyzer.assess("[WPA2-PSK-CCMP][ESS]")
        assertEquals(SecurityLevel.WPA2, a.level)
        assertEquals(Risk.WARN, a.risk)
    }

    @Test fun detectsWpa3() {
        val a = WifiAnalyzer.assess("[RSN-SAE-CCMP][ESS]")
        assertEquals(SecurityLevel.WPA3, a.level)
        assertEquals(Risk.GOOD, a.risk)
    }

    @Test fun detectsWep() {
        assertEquals(SecurityLevel.WEP, WifiAnalyzer.assess("[WEP][ESS]").level)
    }

    @Test fun detectsWps() {
        assertEquals(true, WifiAnalyzer.assess("[WPA2-PSK-CCMP][WPS][ESS]").wpsEnabled)
        assertEquals(false, WifiAnalyzer.assess("[WPA2-PSK-CCMP][ESS]").wpsEnabled)
    }
}
