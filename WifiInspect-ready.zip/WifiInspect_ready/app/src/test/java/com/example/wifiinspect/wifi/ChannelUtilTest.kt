package com.example.wifiinspect.wifi

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelUtilTest {
    @Test fun channel2_4ghz() {
        assertEquals(1, ChannelUtil.channel(2412))
        assertEquals(6, ChannelUtil.channel(2437))
        assertEquals(11, ChannelUtil.channel(2462))
        assertEquals(14, ChannelUtil.channel(2484))
    }

    @Test fun channel5ghz() {
        assertEquals(36, ChannelUtil.channel(5180))
        assertEquals(149, ChannelUtil.channel(5745))
    }

    @Test fun band() {
        assertEquals(ChannelUtil.Band.GHZ_24, ChannelUtil.band(2437))
        assertEquals(ChannelUtil.Band.GHZ_5, ChannelUtil.band(5180))
        assertEquals(ChannelUtil.Band.GHZ_6, ChannelUtil.band(6115))
    }
}
