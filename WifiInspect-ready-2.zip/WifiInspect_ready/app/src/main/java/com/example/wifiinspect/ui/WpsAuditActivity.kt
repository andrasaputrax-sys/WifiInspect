package com.example.wifiinspect.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class WpsAuditActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.title = "WPS & Security Audit"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        fun card(title: String, body: String) {
            val panel = MaterialCardView(this).apply {
                radius = dp(14).toFloat()
                cardElevation = dp(2).toFloat()
                setContentPadding(dp(16), dp(14), dp(16), dp(14))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) }
            }
            val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            content.addView(TextView(this).apply { text = title; textSize = 17f; setTypeface(null, 1) })
            content.addView(TextView(this).apply { text = body; textSize = 14f; setPadding(0, dp(8), 0, 0) })
            panel.addView(content)
            root.addView(panel)
        }
        card("WPS: apa dan risikonya?", "WPS (Wi-Fi Protected Setup) adalah cara memudahkan perangkat bergabung ke router. WPS PIN dapat menambah risiko pada router tertentu. Aplikasi Android biasa tidak dapat memastikan status WPS dari pemindaian udara secara andal.")
        card("Pemeriksaan yang tersedia", "• Informasi jaringan sekitar (SSID, BSSID, sinyal, kanal, keamanan)
• Identifikasi jenis keamanan yang ditampilkan router
• Panduan audit pengaturan router milikmu
• Rekomendasi mengurangi risiko WPS")
        card("Rekomendasi keamanan", "1. Matikan WPS/PIN di pengaturan router jika tidak diperlukan.
2. Gunakan WPA2-AES atau WPA3.
3. Buat kata sandi Wi-Fi panjang dan unik.
4. Perbarui firmware router.
5. Ganti kata sandi admin router yang masih bawaan.")
        card("Password Wi-Fi tersimpan", "Android tidak mengizinkan aplikasi biasa menampilkan semua password Wi-Fi tersimpan. Gunakan fitur berbagi jaringan atau QR Wi-Fi dari pengaturan sistem pada jaringan yang perangkatmu punya akses.")
        val settings = MaterialButton(this).apply {
            text = "Buka Pengaturan Wi-Fi"
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
        }
        root.addView(settings)
        val note = TextView(this).apply {
            text = "Audit ini bersifat informatif dan hanya untuk jaringan yang kamu miliki atau diizinkan untuk diuji. Tidak ada PIN guessing atau pembobolan otomatis."
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(4))
        }
        root.addView(note)
    }
    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
