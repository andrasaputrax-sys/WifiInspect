# WifiInspect

Aplikasi analisis & diagnostik jaringan WiFi. Hanya membaca data yang memang diizinkan
Android untuk dibaca aplikasi biasa (tanpa root, tanpa permission sistem khusus).

## Fitur
- Pemindaian WiFi sekitar: SSID, BSSID, vendor (dari data publik IEEE OUI), frekuensi/channel, kekuatan sinyal.
- Info jaringan yang sedang tersambung.
- Analisis keamanan berbasis apa yang dilaporkan sistem (`ScanResult.capabilities`): OPEN/WEP/WPA2/WPA3, status WPS — dengan penjelasan bahasa sederhana. Tidak ada percobaan sandi/PIN.
- Diagnostik latency & kestabilan ke gateway dan ke DNS publik.
- Riwayat pemindaian tersimpan lokal (Room), tidak dikirim ke server mana pun.
- Pemindaian otomatis berkala (opsional, MATI secara default).

## Batasan yang disengaja (bukan bug)
- **BSSID/SSID "tidak diketahui"**: sejak Android 8+, ini hanya muncul jika izin lokasi presisi (`ACCESS_FINE_LOCATION`) diberikan DAN layanan lokasi aktif. Ini kebijakan privasi Android, aplikasi tidak bisa melewatinya.
- **Tidak bisa auto-connect ke jaringan apa pun**: Android 10+ mengharuskan persetujuan pengguna per-jaringan (`WifiNetworkSuggestion`/`WifiNetworkSpecifier`); aplikasi ini sama sekali tidak mencoba connect ke jaringan manapun.
- **Tidak ada fitur cek/tebak PIN WPS**: ini akan menjadi upaya mengakses jaringan orang lain tanpa izin dan sengaja tidak diimplementasikan. Yang ditampilkan hanya *status* WPS aktif/tidak (info publik dari hasil scan), sebagai peringatan keamanan untuk pemilik jaringan.
- **Hasil scan bisa "lama"**: Android membatasi (`throttle`) jumlah scan WiFi aktif per aplikasi (sekitar 4x/2 menit saat di foreground, lebih ketat di background). Jika scan baru ditolak sistem, aplikasi menampilkan hasil scan terakhir yang tersimpan dan jam pemindaiannya.
- **Latency bukan ICMP murni di semua perangkat**: sejumlah jaringan/ROM memblokir ICMP echo; aplikasi otomatis beralih ke pengukuran waktu buka koneksi TCP dan melabeli metode yang dipakai secara jelas di hasil.
- **Permission `NETWORK_SETTINGS` sengaja tidak diminta**: ini permission level sistem yang tidak akan diberikan ke aplikasi biasa dan tidak relevan untuk fitur yang ada.

## Build dari HP (Termux, lewat GitHub)
1. Push folder ini ke repository GitHub Anda.
2. Workflow `.github/workflows/build.yml` berjalan otomatis setiap push, atau jalankan manual lewat tab **Actions → Build APK → Run workflow**.
3. Unduh APK debug dari **Actions → (run terakhir) → Artifacts → wifiinspect-debug-apk**.

## Data vendor (OUI)
`app/src/main/assets/oui_db.csv` berisi pemetaan 3 oktet pertama MAC address ke nama vendor,
disusun dari data registry publik IEEE (OUI assignments) — data faktual publik, bukan properti
suatu aplikasi tertentu.


## WifiInspect V2 additions
- Added WPS & Security Audit screen with safe router-hardening guidance.
- Added shortcut to Android Wi-Fi Settings.
- Clarifies Android saved-password access limitations.
- No WPS PIN guessing or automated cracking functionality.
